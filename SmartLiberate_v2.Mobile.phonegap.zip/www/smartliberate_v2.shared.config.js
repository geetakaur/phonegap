
// NOTE object below must be a valid JSON
window.SmartLiberate_v2 = $.extend(true, window.SmartLiberate_v2, {
    "config": {
        "endpoints": {
            "db": {
                "local": "",
                "production": ""
            }
        },
        "services": {
            "db": {
                "entities": {
                }
            }
        }
    }
});
