
// NOTE object below must be a valid JSON
window.SmartLiberate_v2 = $.extend(true, window.SmartLiberate_v2, {
    "config": {
        "layoutSet": "slideout",
        "navigation": [
              {
                  "title": "Home",
                  "onExecute": "#Home",
                  "icon": "home"
              },
            //{
            //    "title": "About",
            //    "onExecute": "#About",
            //    "icon": "info"
            //}
          
        ]
    }
});
